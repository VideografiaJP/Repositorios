﻿using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Menu_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button botao && botao.Tag is string caminhoImagem)
            {
                ImagemConteudo.Source = new BitmapImage(new System.Uri(caminhoImagem, System.UriKind.RelativeOrAbsolute));
            }
        }

        private Process processoExterno;

        private void AbrirPrograma_Click(object sender, RoutedEventArgs e)
        {
            // Substitua com o caminho do seu executável
            string caminhoPrograma = @"C:\\program Files (x86)\\vMix\\vMix64.exe";
            string pathArquivovMix = @"S:\1_ENTREGA_VIDEOGRAFIA\VMIX_JOVEMPAN\NEWS\ROLL_DE_COMENTARISTAS\VMIX\TELA_ROLL_COMENTARISTAS_REDACAO.vmix";
            pathArquivovMix = @"S:\1_ENTREGA_VIDEOGRAFIA\VMIX_JOVEMPAN\NEWS\TARJA_NEWS_2025\VMIX\TARJA_NEWS_2025.vmix";
            //pathArquivovMix = @"S:\1_ENTREGA_VIDEOGRAFIA\VMIX_JOVEMPAN\NEWS\TARJA_REDES_SOCIAIS\VMIX\TARJA_COMENTARIO_REDES.vmix";

            if (File.Exists(caminhoPrograma))
            {
                // Encerra o processo anterior, se ainda estiver em execução
                if (processoExterno != null && !processoExterno.HasExited)
                {
                    processoExterno.Kill();       // Encerra forçadamente
                    processoExterno.WaitForExit(); // Aguarda encerramento
                }

                // Inicia novo processo e armazena referência
                processoExterno = Process.Start(new ProcessStartInfo
                {
                    FileName = caminhoPrograma,
                    Arguments = pathArquivovMix,
                    UseShellExecute = true
                });
            }
            else
            {
                MessageBox.Show("Programa não encontrado.");
            }

            //if (File.Exists(caminhoPrograma))
            //    Process.Start(new ProcessStartInfo(caminhoPrograma, pathArquivovMix) { UseShellExecute = true });
            //else
            //    MessageBox.Show("Programa não encontrado.");
        }

        private void AbrirTXT_Click(object sender, RoutedEventArgs e)
        {
            // Substitua com o caminho do seu arquivo .txt
            string caminhoTxt = @"C:\Caminho\Para\Arquivo.txt";

            if (File.Exists(caminhoTxt))
                Process.Start(new ProcessStartInfo("notepad.exe", caminhoTxt) { UseShellExecute = true });
            else
                MessageBox.Show("Arquivo TXT não encontrado.");
        }
    }
}