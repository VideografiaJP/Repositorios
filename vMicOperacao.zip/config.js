const config = {
    ipApiServer : "http://172.16.1.140:3000",
    ipVMix : "10.255.30.221",    
    //ipVMix :  "127.0.0.1"
}